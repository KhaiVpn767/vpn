#!/bin/bash
rm -f /root/-
rm -f /root/login-db.txt
rm -f /root/login-db-pid.txt